package org.springbatch.demo.processor;

import org.springbatch.demo.model.Trade;
import org.springframework.batch.item.ItemProcessor;

public class TradeProcessor implements ItemProcessor<Trade, Trade>{

	@Override
	public Trade process(Trade trade) throws Exception {
		System.out.println("Processing trade: " + trade);
		return trade;
	}

}
