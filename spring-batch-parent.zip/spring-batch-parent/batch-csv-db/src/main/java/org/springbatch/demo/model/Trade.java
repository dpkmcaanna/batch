package org.springbatch.demo.model;

public class Trade {

	private String tradeId;
	private String tradedate;
	private String versionid;
	private String sourcesystem;
	
	
	public Trade() {
		super();
	}

	public Trade(String tradeId, String tradedate, String versionid, String sourcesystem) {
		super();
		this.tradeId = tradeId;
		this.tradedate = tradedate;
		this.versionid = versionid;
		this.sourcesystem = sourcesystem;
	}

	public String getTradeId() {
		return tradeId;
	}

	public void setTradeId(String tradeId) {
		this.tradeId = tradeId;
	}

	public String getTradedate() {
		return tradedate;
	}

	public void setTradedate(String tradedate) {
		this.tradedate = tradedate;
	}

	public String getVersionid() {
		return versionid;
	}

	public void setVersionid(String versionid) {
		this.versionid = versionid;
	}

	public String getSourcesystem() {
		return sourcesystem;
	}

	public void setSourcesystem(String sourcesystem) {
		this.sourcesystem = sourcesystem;
	}

	@Override
	public String toString() {
		return "Trade [tradeId=" + tradeId + ", tradedate=" + tradedate + ", versionid=" + versionid + ", sourcesystem="
				+ sourcesystem + "]";
	}
	
}
