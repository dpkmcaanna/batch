package org.springbatch.demo.config;

import org.apache.tomcat.jdbc.pool.DataSource;
import org.springbatch.demo.listener.JobCompletionListener;
import org.springbatch.demo.model.Trade;
import org.springbatch.demo.processor.TradeProcessor;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.MultiResourceItemReader;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

@Configuration
@EnableBatchProcessing
public class JobConfiguration {

	@Autowired
	private JobBuilderFactory  JobBuilderFactory;
	
	@Autowired
	private StepBuilderFactory stepBuilderFactory;
	
	@Autowired
	private DataSource dataSource;

	@Bean
	public MultiResourceItemReader<Trade> multiResourceReader() {
		MultiResourceItemReader<Trade> multiResourceItemReader = new MultiResourceItemReader<Trade> ();
		multiResourceItemReader.setResources(new Resource[]{});
		return null;
		
	}
	
	@Bean
	public FlatFileItemReader<Trade> reader() {
		FlatFileItemReader<Trade> tradeReader = new FlatFileItemReader<Trade>();
		tradeReader.setLinesToSkip(1);
		tradeReader.setResource(new ClassPathResource("input/*.*"));
		tradeReader.setLineMapper(new DefaultLineMapper<Trade>(){{
			setLineTokenizer(new DelimitedLineTokenizer(){{
				setDelimiter(DELIMITER_COMMA);
				setNames(new String[]{"tradeId", "tradedate", "versionid", "sourcesystem"});
			}});
			setFieldSetMapper(new BeanWrapperFieldSetMapper<Trade>(){{
				setTargetType(Trade.class);
			}});
		}});
		return tradeReader;
	}
	
	@Bean
	public TradeProcessor processor() {
		return new TradeProcessor();
	}
	
	@Bean
	public JdbcBatchItemWriter<Trade> writer() {
		JdbcBatchItemWriter<Trade>  writer = new JdbcBatchItemWriter<Trade> ();
		writer.setItemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>());
		writer.setDataSource(dataSource);
		writer.setSql("INSERT INTO TRADE (TRADE_ID,TRADE_DATE,VERSION_ID,SOURCE_SYSTEM) VALUES (:tradeId, :tradedate, :versionid, :sourcesystem)");
		return writer;
	}
	
	@Bean
	public Job loadTradeJob(JobCompletionListener listener){
		return JobBuilderFactory.get("loadTradeJob").incrementer(new RunIdIncrementer())
				.listener(listener).flow(step1()).end().build();
	}
	
	@Bean
	public Step step1() {
		return stepBuilderFactory.get("step1").<Trade, Trade>chunk(5).reader(reader())
				.processor(processor()).writer(writer()).build();
	}
}
