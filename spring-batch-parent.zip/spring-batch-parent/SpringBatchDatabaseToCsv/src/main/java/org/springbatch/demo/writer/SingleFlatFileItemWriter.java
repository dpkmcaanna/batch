package org.springbatch.demo.writer;

import org.springbatch.demo.model.ModelObject;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.transform.LineAggregator;
import org.springframework.core.io.Resource;

public class SingleFlatFileItemWriter extends FlatFileItemWriter<ModelObject> {

}
