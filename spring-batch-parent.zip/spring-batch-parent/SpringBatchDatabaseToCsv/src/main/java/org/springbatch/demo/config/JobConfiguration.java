package org.springbatch.demo.config;

import org.apache.tomcat.jdbc.pool.DataSource;
import org.springbatch.demo.listener.ExamResultJobListener;
import org.springbatch.demo.mapper.ExamResultRowMapper;
import org.springbatch.demo.model.ExamResult;
import org.springbatch.demo.model.ModelObject;
import org.springbatch.demo.processor.ExamResultItemProcessor;
import org.springbatch.demo.reader.DefaultJdbcCursorItemReader;
import org.springbatch.demo.writer.DefaultBeanWrapperFieldExtractor;
import org.springbatch.demo.writer.SingleFlatFileItemWriter;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.transform.BeanWrapperFieldExtractor;
import org.springframework.batch.item.file.transform.DelimitedLineAggregator;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.batch.support.transaction.ResourcelessTransactionManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

@Configuration
@EnableBatchProcessing
public class JobConfiguration {

	@Value("file:output\\result.txt")
	private Resource resources;
	
	@Autowired
	private JobBuilderFactory  JobBuilderFactory;
	
	@Autowired
	private StepBuilderFactory stepBuilderFactory;
	
	@Autowired
	private DataSource dataSource;
	
	//@Bean
	public DriverManagerDataSource dataSource() {
		DriverManagerDataSource datasource = new DriverManagerDataSource();
		datasource.setDriverClassName("oracle.jdbc.driver.OracleDriver");
		
		return datasource;
	}
	
	@Bean
	public RowMapper<ModelObject> rowMapper() {
		return new ExamResultRowMapper();
	}
	
	@Bean
	public JdbcCursorItemReader<ModelObject> databaseItemReader() {
		DefaultJdbcCursorItemReader reader = new DefaultJdbcCursorItemReader();
		reader.setDataSource(dataSource);
		reader.setSql("SELECT STUDENT_NAME, DOB, PERCENTAGE FROM EXAM_RESULT");
		reader.setRowMapper(rowMapper());
		return reader;
	}
	
	@Bean
	public JobExecutionListener jobListener() {
		return new ExamResultJobListener();
	}
	
	@Bean
	public ItemProcessor<ModelObject, ModelObject> itemProcessor() {
		return new ExamResultItemProcessor();
	}
	
	@Bean
	public BeanWrapperFieldExtractor<ModelObject>  fieldExtractor() {
		DefaultBeanWrapperFieldExtractor filedExtractor =  new DefaultBeanWrapperFieldExtractor();
		filedExtractor.setNames(new String[]{"studentName", "percentage", "dob"});
		return filedExtractor;
	}
	
	@Bean
	public DelimitedLineAggregator<ModelObject> lineAggregator() {
		DelimitedLineAggregator<ModelObject> lineAggregator =   new DelimitedLineAggregator<ModelObject>();
		lineAggregator.setDelimiter("|");
		lineAggregator.setFieldExtractor(fieldExtractor());
		return lineAggregator;
	}
	
	
	@Bean
	public FlatFileItemWriter<ModelObject>  flatFileItemWriter() {		
		SingleFlatFileItemWriter writer =  new SingleFlatFileItemWriter();
		writer.setResource(resources);
		writer.setLineAggregator(lineAggregator());
		return writer;		
	}
	
	@Bean
	public ResourcelessTransactionManager txnManager() {
		return new ResourcelessTransactionManager();
	}
	
	@Bean
	public Job readJob() {
		return JobBuilderFactory.get("readJob").listener(jobListener())
				.flow(readStep()).end().build();
	}
	
	@Bean
	public Step readStep() {
		return stepBuilderFactory.get("readStep").allowStartIfComplete(true).<ModelObject, ModelObject>chunk(5).reader(databaseItemReader())
				.processor(itemProcessor()).writer(flatFileItemWriter()).build();
	}
}
