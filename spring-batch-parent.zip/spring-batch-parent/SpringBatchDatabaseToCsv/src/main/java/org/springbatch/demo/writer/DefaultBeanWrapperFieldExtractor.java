package org.springbatch.demo.writer;

import org.springbatch.demo.model.ModelObject;
import org.springframework.batch.item.file.transform.BeanWrapperFieldExtractor;

public class DefaultBeanWrapperFieldExtractor extends BeanWrapperFieldExtractor<ModelObject>{

}
