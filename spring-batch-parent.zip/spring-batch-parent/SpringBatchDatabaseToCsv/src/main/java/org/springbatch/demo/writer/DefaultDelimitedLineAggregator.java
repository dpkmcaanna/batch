package org.springbatch.demo.writer;

import org.springbatch.demo.model.ModelObject;
import org.springframework.batch.item.file.transform.DelimitedLineAggregator;
import org.springframework.batch.item.file.transform.FieldExtractor;

public class DefaultDelimitedLineAggregator extends DelimitedLineAggregator<ModelObject>{

}
