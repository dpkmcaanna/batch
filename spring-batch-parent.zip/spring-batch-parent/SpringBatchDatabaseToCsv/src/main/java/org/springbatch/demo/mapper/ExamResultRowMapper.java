package org.springbatch.demo.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.joda.time.LocalDate;
import org.springbatch.demo.model.ExamResult;
import org.springbatch.demo.model.ModelObject;
import org.springframework.jdbc.core.RowMapper;

public class ExamResultRowMapper implements RowMapper<ModelObject> {

	@Override
	public ModelObject mapRow(ResultSet rs, int rowNum) throws SQLException {
		ExamResult result = new ExamResult();
        result.setStudentName(rs.getString("student_name"));
        result.setDob(new LocalDate(rs.getDate("dob")));
        result.setPercentage(rs.getDouble("percentage"));
		return result;
	}

}
