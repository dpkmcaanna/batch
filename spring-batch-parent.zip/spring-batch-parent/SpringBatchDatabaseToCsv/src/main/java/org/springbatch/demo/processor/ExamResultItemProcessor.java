package org.springbatch.demo.processor;

import org.springbatch.demo.model.ExamResult;
import org.springbatch.demo.model.ModelObject;
import org.springframework.batch.item.ItemProcessor;

public class ExamResultItemProcessor implements ItemProcessor<ModelObject, ModelObject> {

	@Override
	public ModelObject process(ModelObject item) throws Exception {
		ExamResult result = (ExamResult)item;
		System.out.println("Processing result :"+ result);
		if(result.getPercentage() < 60){
			return null;
		}		
		return result;
	}
}
