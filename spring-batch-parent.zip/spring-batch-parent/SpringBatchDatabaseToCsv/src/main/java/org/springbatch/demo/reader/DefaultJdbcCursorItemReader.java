package org.springbatch.demo.reader;

import org.springbatch.demo.model.ModelObject;
import org.springframework.batch.item.database.JdbcCursorItemReader;

public class DefaultJdbcCursorItemReader extends JdbcCursorItemReader<ModelObject> {

}
