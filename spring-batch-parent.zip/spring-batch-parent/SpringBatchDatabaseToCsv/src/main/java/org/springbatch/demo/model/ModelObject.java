package org.springbatch.demo.model;

public class ModelObject {

}
